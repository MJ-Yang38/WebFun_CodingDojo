$("document").ready(function(){
    $("#0-pos-image").click(function(){
        $(this).attr("src","cat0.png");
    })
    $("#1-pos-image").click(function(){
        $(this).attr("src","cat1.png");
    })
    $("#2-pos-image").click(function(){
        $(this).attr("src","cat2.png");
    })
    $("#3-pos-image").click(function(){
        $(this).attr("src","cat3.png");
    })
    $("#4-pos-image").click(function(){
        $(this).attr("src","cat4.png");
    })
    




})