$("document").ready(function(){
    $("#top-row-1").click(function(){
        $(this).fadeOut();
    })
    $("#top-row-2").click(function(){
        $(this).fadeOut();
    })
    $("#top-row-3").click(function(){
        $(this).fadeOut();
    })
    $("#top-row-4").click(function(){
        $(this).fadeOut();
    })
    $("#bottom-row-1").click(function(){
        $(this).fadeOut();
    })
    $("#bottom-row-2").click(function(){
        $(this).fadeOut();
    })
    $("#bottom-row-3").click(function(){
        $(this).fadeOut();
    })
    $("#bottom-row-4").click(function(){
        $(this).fadeOut();
    })
    $("button").click(function(){
        $("img").fadeIn();
    })




})