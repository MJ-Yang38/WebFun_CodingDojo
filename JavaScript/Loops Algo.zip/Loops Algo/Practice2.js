var num;
var sum=0;
for(var num=1; num<=5; num++){
    sum=num+sum;
    console.log("num:",num);
    console.log("sum:",sum);
}