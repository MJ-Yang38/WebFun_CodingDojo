var testArr = [6,3,5,1,2,4];
var num = 0;
var sum= 0;
for (var i=0; i<testArr.length; i++){
    num = testArr[i];
    sum=sum+num;
    console.log("Num", num, "Sum", sum);
}
